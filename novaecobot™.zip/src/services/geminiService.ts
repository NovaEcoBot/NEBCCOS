import { GoogleGenAI } from "@google/genai";

export async function executeEngine(engineId: number, enginePrompt: string, userInputCommand: string, provider: "gemini" | "anthropic" = "gemini") {
  if (provider === "gemini") {
    try {
      // Safely access Gemini API Key from environment
      let apiKey = "";
      try {
        if (typeof process !== 'undefined' && process.env) {
          apiKey = (process.env.GEMINI_API_TOKEN || process.env.GEMINI_API_KEY || "");
        }
      } catch (e) {
        // ...
      }

      apiKey = apiKey.replace(/['"]+/g, '').trim();

      if (!apiKey || apiKey.length < 10 || apiKey.includes("MY_GEMINI")) {
        throw new Error("AUTH FAILURE: Missing or invalid GEMINI_API_TOKEN. Please link your real key in the Secrets panel (top right).");
      }

      const ai = new GoogleGenAI({ apiKey });

      const finalPrompt = `
        SYSTEM ROLE: You are NovaEcoBot Engine ${engineId}.
        
        BASE ENGINE DEFINITION:
        ${enginePrompt}
        
        USER TARGET COMMAND TO EXECUTE:
        "${userInputCommand}"
        
        STRICT DIRECTIVE: Execute this engine's role perfectly based on the provided user command. 
        Output should be structured, practical, and systemic. Do not summarize. No conversational filler.
      `;

      // Try multiple model aliases
      const modelNames = ["gemini-3-flash-preview", "gemini-2.0-flash", "gemini-1.5-flash"];
      let lastError = null;

      for (const modelName of modelNames) {
        try {
          const response = await ai.models.generateContent({
            model: modelName,
            contents: finalPrompt,
          });

          if (response.text) {
            return response.text;
          }
        } catch (err: any) {
          console.warn(`Model ${modelName} failed:`, err.message);
          lastError = err;
          if (err.message?.includes("API_KEY_INVALID") || err.message?.includes("401") || err.message?.includes("403")) {
            throw new Error(`AUTH FAILURE: ${err.message}`);
          }
          continue;
        }
      }

      throw lastError || new Error("All Gemini models failed.");
    } catch (error: any) {
      console.error(`Gemini Service Error (Engine ${engineId}):`, error);
      const msg = error.message || "Unknown error";
      if (msg.includes("AUTH FAILURE")) throw error;
      throw new Error(`[ENGINE_${engineId}_FAILURE]: ${msg}`);
    }
  }

  try {
    // For Anthropic or other providers, use the backend proxy
    const response = await fetch("/api/execute-engine", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        engineId,
        enginePrompt,
        userInputCommand,
        provider,
      }),
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.error || `Server responded with status ${response.status}`);
    }

    return data.output;
  } catch (error: any) {
    console.error(`Error in Engine ${engineId}:`, error);
    
    let errorMessage = "Unknown system error.";
    if (error.message?.includes("API_KEY_INVALID")) {
      errorMessage = "Invalid API Key. Please check your secrets.";
    } else if (error.message?.includes("quota")) {
      errorMessage = "Resource quota exceeded. Please try again in a few minutes.";
    } else if (error.message) {
      errorMessage = error.message;
    }
    
    throw new Error(`[ENGINE_${engineId}_FAILURE]: ${errorMessage}`);
  }
}
