import React, { useState, useMemo, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Search, 
  ChevronDown, 
  ChevronUp, 
  Copy, 
  Check, 
  LayoutGrid, 
  Terminal, 
  Play, 
  ShieldCheck, 
  Activity, 
  Cpu,
  Globe,
  ArrowRight,
  Loader2,
  Settings,
  AlertTriangle,
  XCircle,
  BarChart3,
  Link,
  Lock,
  Youtube,
  Twitter,
  Facebook,
  Instagram,
  User,
  ExternalLink,
  FileText,
  Shield,
  HelpCircle,
  Mail,
  Home,
  Bot,
  Layers,
  Database,
  Bell,
  Menu,
  X,
  Plus,
  TrendingUp,
  Zap,
  Leaf,
  Box as BoxIcon
} from 'lucide-react';
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  BarChart,
  Bar,
  Cell
} from 'recharts';
import { ENGINES, type EngineData } from './constants';
import { executeEngine } from './services/geminiService';

// --- Types ---
interface EngineResult {
  output?: string;
  error?: string;
  timestamp: number;
  prompt: string;
}

type ViewType = 'landing' | 'dashboard' | 'studio' | 'archives' | 'settings';

// --- Mock Data for Analytics ---
const ANALYTICS_DATA = [
  { name: '01:00', value: 400, sustainability: 240, cost: 45 },
  { name: '04:00', value: 300, sustainability: 139, cost: 30 },
  { name: '08:00', value: 200, sustainability: 980, cost: 20 },
  { name: '12:00', value: 278, sustainability: 390, cost: 33 },
  { name: '16:00', value: 189, sustainability: 480, cost: 25 },
  { name: '20:00', value: 239, sustainability: 380, cost: 29 },
  { name: '23:59', value: 349, sustainability: 430, cost: 38 },
];

const SUSTAINABILITY_SCORE = [
  { name: 'Carbon Offset', value: 85 },
  { name: 'Green Energy', value: 92 },
  { name: 'Resource Eff.', value: 78 },
  { name: 'Waste Reduc.', value: 65 },
];

// --- Components ---

const SustainabilityMap = () => {
  const nodes = [
    { name: 'Tokyo Node', x: '82%', y: '45%', status: 'active' },
    { name: 'London Node', x: '48%', y: '35%', status: 'active' },
    { name: 'NY Data Ctr', x: '25%', y: '42%', status: 'active' },
    { name: 'Amazon Regen', x: '32%', y: '75%', status: 'active' },
    { name: 'Arctic Sentry', x: '50%', y: '15%', status: 'warning' },
    { name: 'Sydney Uplink', x: '85%', y: '82%', status: 'active' },
  ];

  return (
    <div className="relative w-full aspect-video bg-[#0a0c10] border border-white/5 rounded-2xl overflow-hidden p-8">
      <div className="absolute top-8 left-8 z-10">
        <h4 className="text-[10px] font-bold uppercase tracking-[3px] text-white">Global Impact Overlay</h4>
        <p className="text-[8px] text-[#454a5c] uppercase">Active Neural Nodes: 5/6 Online</p>
      </div>
      
      {/* Simple World Map Illustration */}
      <svg viewBox="0 0 1000 500" className="w-full h-full opacity-20 filter grayscale invert">
        <path fill="currentColor" d="M150,150 Q250,50 400,100 T700,50 900,150 L950,400 Q800,450 600,400 T300,450 50,400 Z" />
        <path fill="currentColor" d="M200,300 Q300,250 400,300 T600,250 800,300" stroke="white" strokeWidth="2" fill="none" opacity="0.3" />
      </svg>

      {/* Nodes */}
      {nodes.map((node, i) => (
        <motion.div
          key={i}
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ delay: i * 0.2 }}
          style={{ left: node.x, top: node.y }}
          className="absolute -translate-x-1/2 -translate-y-1/2 group cursor-pointer"
        >
          <div className={`w-3 h-3 rounded-full ${node.status === 'active' ? 'bg-neon-green' : 'bg-yellow-500'} shadow-[0_0_10px_currentColor] animate-pulse`} />
          <div className="absolute top-full mt-2 left-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-opacity bg-black/90 border border-white/10 px-2 py-1 rounded whitespace-nowrap z-20">
            <p className="text-[8px] text-white font-bold uppercase">{node.name}</p>
          </div>
        </motion.div>
      ))}

      {/* Decorative Lines */}
      <svg className="absolute inset-0 w-full h-full pointer-events-none">
        <motion.path
          d="M 250,210 L 480,175 L 820,225"
          fill="none"
          stroke="#00e87a"
          strokeWidth="0.5"
          strokeDasharray="4 4"
          initial={{ pathLength: 0 }}
          animate={{ pathLength: 1 }}
          transition={{ duration: 2, repeat: Infinity, repeatDelay: 1 }}
          opacity="0.3"
        />
      </svg>
    </div>
  );
};

const StatusBadge: React.FC<{ type: 'active' | 'warning' | 'error' | 'neutral', text: string }> = ({ type, text }) => {
  const styles = {
    active: 'bg-neon-green/10 text-neon-green border-neon-green/20',
    warning: 'bg-yellow-500/10 text-yellow-500 border-yellow-500/20',
    error: 'bg-red-500/10 text-red-500 border-red-500/20',
    neutral: 'bg-white/5 text-[#7a7f96] border-white/10',
  };

  return (
    <div className={`px-2 py-0.5 rounded text-[9px] font-mono border uppercase tracking-wider ${styles[type]}`}>
      {text}
    </div>
  );
};

const EngineCard: React.FC<{ 
  engine: EngineData, 
  index: number, 
  isExpanded: boolean, 
  onToggle: () => void,
  executionResult?: EngineResult,
  isExecuting?: boolean
}> = ({ 
  engine, 
  index, 
  isExpanded, 
  onToggle, 
  executionResult,
  isExecuting 
}) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = (e: React.MouseEvent) => {
    e.stopPropagation();
    const textToCopy = executionResult?.error 
      ? `Error in ${engine.name}: ${executionResult.error}`
      : executionResult?.output || engine.command;
    navigator.clipboard.writeText(textToCopy);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const hasError = !!executionResult?.error;

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.05 }}
      id={`engine-${engine.id}`}
      className={`bg-[#0a0c10] border rounded-xl overflow-hidden group transition-all duration-300 ${
        isExecuting 
          ? 'border-neon-green/40 shadow-[0_0_20px_rgba(0,255,65,0.05)]' 
          : hasError 
            ? 'border-red-500/40' 
            : 'border-white/5 hover:border-white/20'
      }`}
    >
      <div 
        onClick={onToggle}
        className={`p-5 flex items-center justify-between cursor-pointer transition-colors ${executionResult ? 'bg-white/5' : ''}`}
      >
        <div className="flex items-center gap-4">
          <div className={`w-10 h-10 rounded-lg flex items-center justify-center text-xl transition-all ${isExecuting ? 'bg-neon-green text-black scale-110 font-bold' : 'bg-white/5 grayscale group-hover:grayscale-0'}`}>
            {engine.icon}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className={`font-sans text-sm font-bold tracking-tight ${hasError ? 'text-red-400' : 'text-white'}`}>{engine.name}</h3>
              <StatusBadge type={isExecuting ? 'active' : hasError ? 'error' : 'neutral'} text={isExecuting ? 'Executing' : hasError ? 'Fault' : 'Standby'} />
            </div>
            <p className="text-[10px] text-[#454a5c] uppercase tracking-widest mt-0.5">{engine.subtitle}</p>
          </div>
        </div>
        
        <div className="flex items-center gap-2">
          {executionResult && (
            <button 
              onClick={handleCopy}
              className="p-2 text-[#454a5c] hover:text-white transition-colors"
              title="Copy Output"
            >
              {copied ? <Check size={14} className="text-neon-green" /> : <Copy size={14} />}
            </button>
          )}
          <div className={`p-1.5 transition-transform ${isExpanded ? 'rotate-180' : ''}`}>
            <ChevronDown size={16} className="text-[#454a5c]" />
          </div>
        </div>
      </div>

      <AnimatePresence>
        {isExpanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="border-t border-white/5"
          >
            <div className="p-5 font-mono text-[11px] leading-relaxed relative min-h-[100px]">
              {isExecuting && (
                <div className="absolute inset-0 bg-black/60 flex flex-col items-center justify-center backdrop-blur-[2px] z-10 transition-all">
                  <Loader2 className="animate-spin text-neon-green mb-2" size={20} />
                  <span className="text-[8px] text-neon-green tracking-[3px] uppercase">Processing Data</span>
                </div>
              )}
              
              {hasError ? (
                <div className="text-red-400 bg-red-400/5 p-4 rounded border border-red-500/20">
                  <p className="font-bold mb-2 uppercase flex items-center gap-2"><XCircle size={12} /> Execution Error</p>
                  <p className="opacity-80">{executionResult?.error}</p>
                </div>
              ) : executionResult?.output ? (
                <div className="space-y-4">
                  <div className="text-white/90 whitespace-pre-wrap">
                    {executionResult.output}
                  </div>
                  <div className="flex gap-4 pt-4 border-t border-white/5">
                    <div className="flex-1">
                      <p className="text-[#454a5c] text-[8px] uppercase mb-1 text-[7px] tracking-widest">Impact Radius</p>
                      <div className="h-1 bg-white/5 rounded-full overflow-hidden">
                        <div className="h-full bg-neon-green w-[85%]" />
                      </div>
                    </div>
                    <div className="flex-1">
                      <p className="text-[#454a5c] text-[8px] uppercase mb-1 text-[7px] tracking-widest">Efficiency</p>
                      <div className="h-1 bg-white/5 rounded-full overflow-hidden">
                        <div className="h-full bg-blue-500 w-[92%]" />
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="text-[#454a5c] italic opacity-40">{engine.command.substring(0, 200)}...</div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
};

export default function App() {
  const [activeTab, setActiveTab] = useState<ViewType>('landing');
  const [search, setSearch] = useState('');
  const [expandedIds, setExpandedIds] = useState<number[]>([]);
  const [userInput, setUserInput] = useState('');
  const [provider, setProvider] = useState<'gemini' | 'anthropic'>('gemini');
  const [isProcessing, setIsProcessing] = useState(false);
  const [currentExecutingId, setCurrentExecutingId] = useState<number | null>(null);
  const [results, setResults] = useState<Record<number, EngineResult>>({});
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [history, setHistory] = useState<EngineResult[]>([]);

  // Load history from localStorage on mount
  useEffect(() => {
    const saved = localStorage.getItem('nova_archives');
    if (saved) {
      try {
        setHistory(JSON.parse(saved));
      } catch (e) {
        console.error("Failed to parse archives");
      }
    }
  }, []);

  const filteredEngines = useMemo(() => {
    return ENGINES.filter(e => 
      e.name.toLowerCase().includes(search.toLowerCase()) || 
      e.subtitle.toLowerCase().includes(search.toLowerCase())
    );
  }, [search]);

  const toggleEngine = (id: number) => {
    setExpandedIds(prev => 
      prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
    );
  };

  const handleSystemExecution = async () => {
    if (!userInput.trim() || isProcessing) return;

    setIsProcessing(true);
    setResults({});
    setActiveTab('studio');
    setExpandedIds([ENGINES[0].id]);
    
    let previousOutput = userInput;
    const sessionResults: Record<number, EngineResult> = {};

    for (const engine of ENGINES) {
      setCurrentExecutingId(engine.id);
      setExpandedIds(prev => [...new Set([...prev, engine.id])]);
      
      try {
        const contextPrompt = previousOutput !== userInput 
          ? `PREVIOUS_ENGINE_OUTPUT: ${previousOutput.substring(0, 500)}...\n\nPRIMARY_OBJECTIVE: ${userInput}`
          : userInput;

        const result = await executeEngine(engine.id, engine.command, contextPrompt, provider);
        const engineRes = { output: result, timestamp: Date.now(), prompt: userInput };
        sessionResults[engine.id] = engineRes;
        setResults(prev => ({ ...prev, [engine.id]: engineRes }));
        previousOutput = result;
      } catch (error: any) {
        const errorRes = { error: error.message, timestamp: Date.now(), prompt: userInput };
        sessionResults[engine.id] = errorRes;
        setResults(prev => ({ ...prev, [engine.id]: errorRes }));
        if (error.message.includes('AUTH FAILURE')) break;
      }
    }

    // Save final output to archives if successful
    const finalResult = sessionResults[ENGINES[ENGINES.length - 1].id];
    if (finalResult && !finalResult.error) {
      const newHistory = [finalResult, ...history].slice(0, 50);
      setHistory(newHistory);
      localStorage.setItem('nova_archives', JSON.stringify(newHistory));
    }

    setCurrentExecutingId(null);
    setIsProcessing(false);
  };

  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: Home },
    { id: 'studio', label: 'Intelligence Studio', icon: Bot },
    { id: 'archives', label: 'Neural Archives', icon: Database },
    { id: 'settings', label: 'System Config', icon: Settings },
  ];

  return (
    <div className="flex h-screen bg-[#050608] text-white font-sans selection:bg-neon-green selection:text-black overflow-hidden leading-normal">
      {/* Sidebar */}
      <aside className={`fixed inset-y-0 left-0 z-50 w-64 bg-[#0a0c10] border-r border-white/5 transition-transform duration-300 transform ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'} md:relative md:translate-x-0 ${activeTab === 'landing' ? 'md:hidden' : 'flex'} flex-col`}>
        <div className="p-6">
          <div className="flex items-center gap-3 mb-8">
            <div className="w-8 h-8 bg-neon-green rounded flex items-center justify-center text-black font-black text-xs">NB</div>
            <h1 className="text-sm font-bold tracking-tighter uppercase">NovaEcoBot™</h1>
          </div>

          <nav className="space-y-1">
            {menuItems.map((item) => {
              const Icon = item.icon || Layers;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id as ViewType)}
                  className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-lg text-xs font-medium transition-all ${
                    activeTab === item.id 
                    ? 'bg-neon-green/10 text-neon-green' 
                    : 'text-[#454a5c] hover:bg-white/5 hover:text-white'
                  }`}
                >
                  <Icon size={16} />
                  {item.label}
                </button>
              );
            })}
          </nav>
        </div>

        <div className="mt-auto p-6 space-y-6">
          <div className="p-4 bg-white/5 rounded-xl border border-white/5">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center">
                <User size={14} className="text-[#7a7f96]" />
              </div>
              <div className="text-[10px]">
                <p className="font-bold text-white uppercase">Murli Dhar</p>
                <p className="text-[#454a5c] uppercase">Arch-Admin</p>
              </div>
            </div>
            <div className="flex items-center justify-between text-[8px] text-neon-green uppercase font-mono tracking-widest">
              <span>System Online</span>
              <div className="w-1.5 h-1.5 rounded-full bg-neon-green animate-pulse" />
            </div>
          </div>

          <a href="mailto:novaecobot@gmail.com" className="flex items-center gap-3 px-4 py-2 rounded-lg text-[10px] text-[#454a5c] hover:text-white hover:bg-white/5 transition-colors border border-transparent hover:border-white/5">
             <Mail size={14} />
             Support Uplink
          </a>
        </div>
      </aside>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 bg-[#050608] relative">
        {/* Header */}
        <header className="h-16 border-b border-white/5 bg-[#050608]/80 backdrop-blur-md flex items-center justify-between px-8 sticky top-0 z-40">
          <div className="flex items-center gap-4">
            {activeTab !== 'landing' && (
              <button onClick={() => setIsSidebarOpen(!isSidebarOpen)} className="md:hidden text-[#454a5c]">
                <Menu size={20} />
              </button>
            )}
            <h2 className="text-xs font-bold uppercase tracking-[0.2em] text-[#7a7f96]">
              {activeTab === 'landing' ? 'Welcome to NovaEco' : activeTab.replace('-', ' ')}
            </h2>
          </div>

          <div className="flex items-center gap-6">
            <div className="hidden md:flex items-center gap-2 bg-white/5 px-3 py-1.5 rounded-full border border-white/5">
              <TrendingUp size={12} className="text-neon-green" />
              <span className="text-[9px] font-mono text-neon-green uppercase font-bold tracking-wider">Uptime: 99.9%</span>
            </div>
            {activeTab !== 'landing' ? (
              <>
                <div className="relative">
                  <Bell size={18} className="text-[#454a5c] hover:text-white transition-colors cursor-pointer" />
                  <span className="absolute -top-1 -right-1 w-2 h-2 bg-neon-green rounded-full border-2 border-[#050608]" />
                </div>
                <Settings size={18} className="text-[#454a5c] hover:text-white transition-colors cursor-pointer" onClick={() => setActiveTab('settings')} />
              </>
            ) : (
              <button 
                onClick={() => setActiveTab('dashboard')}
                className="bg-neon-green text-black px-4 py-1.5 rounded-full text-[10px] font-bold uppercase tracking-widest hover:scale-105 transition-transform"
              >
                Launch App
              </button>
            )}
          </div>
        </header>

        {/* Dynamic View Scrollable Container */}
        <main className="flex-1 overflow-y-auto custom-scrollbar p-8">
          <AnimatePresence mode="wait">
            {activeTab === 'landing' && (
              <motion.div
                key="landing"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="max-w-6xl mx-auto h-full flex flex-col items-center justify-center text-center space-y-12"
              >
                <div className="relative">
                  <div className="absolute inset-0 blur-3xl bg-neon-green/20 rounded-full scale-150 animate-pulse" />
                  <div className="relative text-9xl">🌿</div>
                </div>
                
                <div className="space-y-6">
                  <h1 className="text-6xl md:text-8xl font-black text-white uppercase tracking-tighter leading-none">
                    NOVAECO<span className="text-neon-green">BOT™</span>
                  </h1>
                  <p className="text-xl md:text-2xl text-[#7a7f96] uppercase font-mono tracking-widest max-w-2xl mx-auto">
                    Smart sustainability solutions for a better future.
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-8 w-full max-w-4xl text-left">
                  {[
                    { title: 'Neural Intelligence', desc: 'Predictive modeling for planetary resource optimization.', icon: Cpu },
                    { title: 'Circular Economies', desc: 'Closed-loop production intelligence for modern industries.', icon: Layers },
                    { title: 'Verified Impact', desc: 'Immutable tracking of every gram of carbon removed.', icon: ShieldCheck },
                  ].map((feature, i) => (
                    <div key={i} className="p-6 bg-[#0a0c10] border border-white/5 rounded-2xl">
                      <feature.icon className="text-neon-green mb-4" size={24} />
                      <h4 className="text-white font-bold uppercase text-xs mb-2 tracking-widest font-mono">{feature.title}</h4>
                      <p className="text-[#454a5c] text-[10px] uppercase leading-relaxed">{feature.desc}</p>
                    </div>
                  ))}
                </div>

                <button 
                  onClick={() => setActiveTab('dashboard')}
                  className="group flex items-center gap-4 bg-white text-black pl-10 pr-4 py-4 rounded-full font-black text-xs uppercase tracking-[0.3em] hover:bg-neon-green hover:shadow-[0_0_50px_rgba(0,255,105,0.4)] transition-all transform hover:-translate-y-1"
                >
                  Enter Intelligence Matrix
                  <div className="w-10 h-10 bg-black rounded-full flex items-center justify-center text-white group-hover:bg-black/80">
                    <ArrowRight size={20} />
                  </div>
                </button>
              </motion.div>
            )}
            {activeTab === 'dashboard' && (
              <motion.div
                key="dashboard"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="max-w-6xl mx-auto space-y-12 pb-20"
              >
                {/* Hero Stats */}
                <section className="grid grid-cols-1 md:grid-cols-4 gap-6">
                  {[
                    { label: 'Neural Process Velocity', value: '4.2k ops', trend: '+12%', icon: Zap, color: 'text-yellow-400' },
                    { label: 'Sustainability Index', value: '94.8', trend: '+5.2%', icon: Leaf, color: 'text-neon-green' },
                    { label: 'Intelligence Depth', value: 'Level 12', trend: 'MAX', icon: Cpu, color: 'text-blue-400' },
                    { label: 'Network Integrity', value: '99.99%', trend: 'Stable', icon: ShieldCheck, color: 'text-purple-400' },
                  ].map((stat, i) => (
                    <div key={i} className="bg-[#0a0c10] p-6 rounded-2xl border border-white/5 relative overflow-hidden group">
                      <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:opacity-10 transition-opacity">
                        <stat.icon size={48} />
                      </div>
                      <p className="text-[10px] text-[#454a5c] uppercase font-bold tracking-[2px] mb-2">{stat.label}</p>
                      <div className="flex items-end justify-between">
                        <h4 className="text-2xl font-bold tracking-tighter">{stat.value}</h4>
                        <span className={`text-[10px] font-mono ${stat.color}`}>{stat.trend}</span>
                      </div>
                    </div>
                  ))}
                </section>

                {/* Charts Section */}
                <section className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                  <div className="lg:col-span-2">
                    <SustainabilityMap />
                  </div>
                  <div className="bg-[#0a0c10] p-8 rounded-2xl border border-white/5">
                    <h3 className="text-sm font-bold uppercase tracking-widest mb-8 text-center underline">Eco Efficiency</h3>
                    <div className="h-[300px] w-full">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={SUSTAINABILITY_SCORE}>
                          <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 8, fill: '#454a5c' }} />
                          <Tooltip 
                            contentStyle={{ backgroundColor: '#0a0c10', border: '1px solid #1a1c22', borderRadius: '8px', fontSize: '10px' }}
                          />
                          <Bar dataKey="value" radius={[4, 4, 0, 0]}>
                            {SUSTAINABILITY_SCORE.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={index === 1 ? '#00e87a' : '#1a1c22'} />
                            ))}
                          </Bar>
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                    <div className="mt-8 pt-8 border-t border-white/5 space-y-4">
                       <div className="flex justify-between text-[10px]">
                          <span className="text-[#454a5c] uppercase">System Carbon Footprint</span>
                          <span className="text-neon-green font-mono">-14 kg CO2e</span>
                       </div>
                       <div className="flex justify-between text-[10px]">
                          <span className="text-[#454a5c] uppercase">Energy Source</span>
                          <span className="text-white">Hydro-Neural Array</span>
                       </div>
                    </div>
                  </div>
                </section>

                {/* Recent Activities */}
                <section className="bg-[#0a0c10] border border-white/5 rounded-2xl overflow-hidden">
                  <div className="px-8 py-6 border-b border-white/5 flex items-center justify-between">
                    <h3 className="text-xs font-bold uppercase tracking-widest flex items-center gap-2">
                       <Activity size={14} className="text-neon-green" /> Recent Intelligence Ops
                    </h3>
                    <button className="text-[10px] text-neon-green uppercase font-bold hover:underline">View All</button>
                  </div>
                  <div className="divide-y divide-white/5">
                    {[
                       { task: 'Market Disruption Analysis', engine: 'E01-E04', time: '14m ago', status: 'Complete' },
                       { task: 'Gen-Z Viral Deconstruction', engine: 'E09', time: '1h ago', status: 'Complete' },
                       { task: 'Luxury Psychology Map', engine: 'E07-E12', time: '3h ago', status: 'Complete' },
                       { task: 'Modular Brand Strategy', engine: 'Full Chain', time: '5h ago', status: 'Complete' },
                    ].map((item, i) => (
                      <div key={i} className="px-8 py-4 flex items-center justify-between hover:bg-white/5 transition-colors group">
                        <div className="flex items-center gap-4">
                          <div className="w-8 h-8 rounded bg-white/5 flex items-center justify-center text-[#454a5c] group-hover:text-neon-green transition-colors">
                            <Database size={14} />
                          </div>
                          <div>
                            <p className="text-[11px] font-bold text-white uppercase">{item.task}</p>
                            <p className="text-[9px] text-[#454a5c] uppercase">{item.engine}</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="text-[10px] text-white/60 mb-1">{item.time}</p>
                          <StatusBadge type="active" text={item.status} />
                        </div>
                      </div>
                    ))}
                  </div>
                </section>
              </motion.div>
            )}

            {activeTab === 'studio' && (
              <motion.div
                key="studio"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="max-w-5xl mx-auto pb-20"
              >
                {/* Branding Section */}
                <section className="mb-12 p-10 bg-gradient-to-br from-neon-green/10 via-transparent to-transparent border border-white/5 rounded-3xl flex flex-col md:flex-row items-center gap-12 relative overflow-hidden">
                  <div className="absolute -bottom-20 -right-20 text-white/5 opacity-5 pointer-events-none">
                    <Bot size={400} />
                  </div>
                  <div className="text-7xl bg-white/5 w-24 h-24 rounded-2xl flex items-center justify-center border border-white/5 shadow-2xl">🌿</div>
                  <div>
                    <h3 className="text-4xl font-black text-white uppercase tracking-tighter mb-3">Intelligence Studio</h3>
                    <p className="text-sm text-[#7a7f96] uppercase tracking-widest font-medium max-w-lg mb-6 leading-relaxed">
                      Deploy the inter-locking 12-Engine Performance chain. Each module compounds neural depth to engineer absolute market dominance.
                    </p>
                    <div className="flex gap-3">
                      <div className="flex items-center gap-2 px-3 py-1.5 bg-neon-green/10 border border-neon-green/20 rounded-full text-[9px] text-neon-green font-bold uppercase">
                        Active Engines: 12
                      </div>
                      <div className="flex items-center gap-2 px-3 py-1.5 bg-white/5 border border-white/10 rounded-full text-[9px] text-[#7a7f96] font-bold uppercase">
                        Encryption: AES-256
                      </div>
                    </div>
                  </div>
                </section>

                <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                  <div className="lg:col-span-12">
                    <div className="bg-[#0a0c10] p-8 rounded-3xl border border-white/5 space-y-6 mb-12">
                       <div className="flex items-center gap-3 mb-2">
                          <Terminal size={14} className="text-neon-green" />
                          <h4 className="text-[10px] font-bold uppercase tracking-[3px] text-[#454a5c]">Operational Payload Input</h4>
                       </div>
                       <div className="flex flex-col gap-4">
                          <textarea 
                            value={userInput}
                            onChange={(e) => setUserInput(e.target.value)}
                            className="w-full h-40 bg-black/40 border border-white/10 rounded-2xl p-6 font-mono text-sm outline-none focus:border-neon-green/40 transition-all resize-none text-white/90 placeholder:text-[#454a5c]"
                            placeholder=">> Define your strategic objective [e.g., 'Infiltrate high-end photography niche within 11 days using narrative warfare']"
                          />
                          <div className="flex items-center justify-between">
                             <div className="flex items-center gap-4">
                               <button 
                                 onClick={() => setProvider('gemini')}
                                 className={`px-4 py-2 rounded-lg text-[10px] font-bold uppercase transition-all ${provider === 'gemini' ? 'bg-neon-green text-black' : 'text-[#454a5c] hover:text-white'}`}
                               >
                                 Gemini Pro
                               </button>
                               <button 
                                 onClick={() => setProvider('anthropic')}
                                 className={`px-4 py-2 rounded-lg text-[10px] font-bold uppercase transition-all ${provider === 'anthropic' ? 'bg-[#ff6c37] text-white' : 'text-[#454a5c] hover:text-white'}`}
                               >
                                 Claude 3.5
                               </button>
                             </div>
                             <button 
                               onClick={handleSystemExecution}
                               disabled={isProcessing || !userInput.trim()}
                               className={`px-10 py-3 rounded-xl flex items-center gap-3 transition-all duration-500 font-bold uppercase text-xs tracking-widest ${
                                 isProcessing 
                                 ? 'bg-white/5 text-[#454a5c] cursor-not-allowed border border-white/5' 
                                 : 'bg-white text-black hover:bg-neon-green hover:shadow-[0_0_30px_rgba(0,255,105,0.3)]'
                               }`}
                             >
                               {isProcessing ? <Loader2 className="animate-spin" size={16} /> : <Play size={16} fill="currentColor" />}
                               {isProcessing ? 'Processing Chain' : 'Deploy Payload'}
                             </button>
                          </div>
                       </div>
                    </div>

                    <div className="space-y-6">
                      <div className="flex items-center justify-between px-4 mb-4">
                         <div className="flex items-center gap-4">
                           <h4 className="text-[10px] font-bold uppercase tracking-[3px] text-[#454a5c]">Module Stack</h4>
                           <input 
                             type="text" 
                             placeholder="Search Array..." 
                             className="bg-transparent border-b border-white/5 text-[10px] py-1 outline-none focus:border-neon-green/30 transition-all text-white/60"
                             value={search}
                             onChange={(e) => setSearch(e.target.value)}
                           />
                         </div>
                         <button 
                          onClick={() => setExpandedIds(expandedIds.length === 0 ? ENGINES.map(e => e.id) : [])}
                          className="text-[9px] uppercase font-bold text-neon-green"
                         >
                            {expandedIds.length === 0 ? 'Expand All' : 'Collapse All'}
                         </button>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {filteredEngines.map((engine, i) => (
                          <EngineCard 
                            key={engine.id} 
                            engine={engine} 
                            index={i} 
                            isExpanded={expandedIds.includes(engine.id)}
                            onToggle={() => toggleEngine(engine.id)}
                            isExecuting={currentExecutingId === engine.id}
                            executionResult={results[engine.id]}
                          />
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {activeTab === 'archives' && (
               <motion.div
                 key="archives"
                 initial={{ opacity: 0, scale: 0.95 }}
                 animate={{ opacity: 1, scale: 1 }}
                 exit={{ opacity: 0, scale: 1.05 }}
                 className="max-w-6xl mx-auto pb-20"
               >
                 <div className="flex items-center justify-between mb-12">
                   <div>
                     <h2 className="text-3xl font-black text-white uppercase tracking-tighter">Neural Archives</h2>
                     <p className="text-[10px] text-[#454a5c] uppercase tracking-[4px] mt-2">Historical Payload Memory Stack</p>
                   </div>
                   <div className="flex gap-4">
                     <div className="px-4 py-2 bg-white/5 border border-white/10 rounded-lg text-xs font-mono">
                       <span className="text-[#454a5c] mr-2">CAPACITY:</span>
                       <span className="text-neon-green">{history.length} / 50</span>
                     </div>
                     <button 
                       onClick={() => {
                        if(confirm('Delete all history?')) {
                          setHistory([]);
                          localStorage.removeItem('nova_archives');
                        }
                       }}
                       className="p-2 border border-red-500/20 text-red-500/60 hover:text-red-500 hover:border-red-500 transition-colors rounded-lg"
                     >
                       <XCircle size={18} />
                     </button>
                   </div>
                 </div>

                 {history.length === 0 ? (
                    <div className="flex flex-col items-center justify-center py-32 text-center border-2 border-dashed border-white/5 rounded-3xl">
                      <Database size={48} className="text-white/10 mb-6" />
                      <p className="text-sm text-[#454a5c] font-mono uppercase tracking-widest">No archived data detected</p>
                    </div>
                 ) : (
                   <div className="grid grid-cols-1 gap-4">
                     {history.map((item, idx) => (
                       <div key={idx} className="bg-[#0a0c10] border border-white/5 p-6 rounded-2xl hover:border-neon-green/30 transition-all group">
                         <div className="flex justify-between items-start mb-4">
                           <div className="space-y-1">
                             <div className="flex items-center gap-3">
                               <StatusBadge type="active" text="Archived Payload" />
                               <span className="text-[10px] text-[#454a5c] font-mono">{new Date(item.timestamp).toLocaleString()}</span>
                             </div>
                             <h4 className="text-white font-bold text-sm tracking-tight line-clamp-1">{item.prompt}</h4>
                           </div>
                           <button 
                             onClick={() => {
                               setUserInput(item.prompt);
                               setActiveTab('studio');
                             }}
                             className="text-[9px] text-neon-green uppercase font-bold tracking-widest hover:underline opacity-0 group-hover:opacity-100 transition-opacity"
                           >
                             Restore Concept
                           </button>
                         </div>
                         <div className="bg-black/40 p-4 rounded-lg font-mono text-[11px] text-white/70 line-clamp-3">
                           {item.output}
                         </div>
                       </div>
                     ))}
                   </div>
                 )}
               </motion.div>
            )}

            {activeTab === 'settings' && (
              <motion.div
                key="settings"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="max-w-3xl mx-auto py-12"
              >
                <h3 className="text-xl font-black uppercase tracking-widest mb-10 border-b border-white/5 pb-6">System Configuration</h3>
                
                <div className="space-y-12">
                  <section>
                    <h4 className="text-[10px] font-bold uppercase tracking-[3px] text-[#454a5c] mb-6">Environment Metadata</h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                       <div className="p-4 bg-white/5 rounded-xl border border-white/5">
                          <p className="text-[8px] text-[#454a5c] uppercase mb-1">Architecture</p>
                          <p className="text-xs font-mono">NovaEco-V10-Hybrid</p>
                       </div>
                       <div className="p-4 bg-white/5 rounded-xl border border-white/5">
                          <p className="text-[8px] text-[#454a5c] uppercase mb-1">Security Protocol</p>
                          <p className="text-xs font-mono">Quantum-Resistant AES</p>
                       </div>
                    </div>
                  </section>

                  <section>
                    <h4 className="text-[10px] font-bold uppercase tracking-[3px] text-[#454a5c] mb-6">API Core Provisioning</h4>
                    <div className="p-6 bg-white/5 rounded-2xl border border-white/5 space-y-6">
                      <div className="flex items-center justify-between">
                         <div>
                            <p className="text-xs font-bold uppercase tracking-widest">Gemini Neural Link</p>
                            <p className="text-[10px] text-[#454a5c] uppercase">Used for primary reasoning and extraction</p>
                         </div>
                         <StatusBadge type="active" text="Connected" />
                      </div>
                      <div className="flex items-center justify-between">
                         <div>
                            <p className="text-xs font-bold uppercase tracking-widest">Anthropic Claude Pulse</p>
                            <p className="text-[10px] text-[#454a5c] uppercase">High-precision creative synthesis</p>
                         </div>
                         <StatusBadge type="neutral" text="Ready" />
                      </div>
                    </div>
                  </section>

                  <div className="pt-10 border-t border-white/5">
                    <button className="flex items-center gap-2 text-red-500 font-bold uppercase text-[10px] tracking-widest hover:underline">
                       <XCircle size={14} /> Full System Purge
                    </button>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </main>

        <footer className="h-12 border-t border-white/5 bg-[#0a0c10] px-8 flex items-center justify-between shrink-0 z-40">
           <div className="flex gap-6 items-center">
              <span className="text-[8px] text-[#454a5c] uppercase font-bold tracking-widest">© 2026 NovaEcoBot™</span>
              <div className="flex items-center gap-2">
                 <div className="w-1.5 h-1.5 rounded-full bg-neon-green" />
                 <span className="text-[8px] text-white/40 uppercase tracking-widest font-mono">Node ID: S-Alpha-09</span>
              </div>
           </div>
           <div className="flex gap-4">
              <a href="#" className="text-[8px] text-[#454a5c] hover:text-white uppercase transition-colors tracking-widest font-mono">Privacy Protocol</a>
              <a href="#" className="text-[8px] text-[#454a5c] hover:text-white uppercase transition-colors tracking-widest font-mono">Legal Terms</a>
           </div>
        </footer>
      </div>

      <style dangerouslySetInnerHTML={{ __html: `
        .custom-scrollbar::-webkit-scrollbar { width: 4px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: #1a1c22; border-radius: 10px; }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover { background: #00e87a; }
      `}} />
    </div>
  );
}
