import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import { createServer as createViteServer } from "vite";
import dotenv from "dotenv";
import Anthropic from "@anthropic-ai/sdk";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Routes
  app.get("/api/health", (req, res) => {
    res.json({ status: "online", version: "10.0", system: "NovaEcoBot" });
  });

  app.post("/api/execute-engine", async (req, res) => {
    const { engineId, enginePrompt, userInputCommand, provider = "gemini" } = req.body;

    if (provider !== "anthropic") {
      return res.status(400).json({ error: "Provider not supported on server. Gemini should be called from the client." });
    }

    let anthropicKey = process.env.ANTHROPIC_API_KEY;
    if (anthropicKey) {
      anthropicKey = anthropicKey.replace(/['"]+/g, '').trim();
    }

    if (!anthropicKey || anthropicKey === "MY_ANTHROPIC_API_KEY" || anthropicKey.length < 20) {
      return res.status(400).json({ 
        error: "CRITICAL AUTH FAILURE: ANTHROPIC_API_KEY is missing or invalid. Please link your real key in the Secrets panel." 
      });
    }

    try {
      const anthropic = new Anthropic({ apiKey: anthropicKey });
      const finalPrompt = `
          SYSTEM ROLE: You are NovaEcoBot Engine ${engineId}.
          
          BASE ENGINE DEFINITION:
          ${enginePrompt}
          
          USER TARGET COMMAND TO EXECUTE:
          "${userInputCommand}"
          
          STRICT DIRECTIVE: Execute this engine's role perfectly based on the provided user command. 
          Output should be structured, practical, and systemic. Do not summarize. No conversational filler.
        `;

      const message = await anthropic.messages.create({
        model: "claude-3-5-sonnet-20240620",
        max_tokens: 4096,
        messages: [{ role: "user", content: finalPrompt }],
      });

      const text = message.content[0].type === 'text' ? message.content[0].text : 'No text content available';
      res.json({ output: text });
    } catch (error: any) {
      console.error(`Anthropic Backend Error in Engine ${engineId}:`, error);
      res.status(500).json({ error: error.message || "Failed to execute engine via Anthropic." });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`🚀 NovaEcoBot™ V10.0 (Production Mode) online at http://localhost:${PORT}`);
  });
}

startServer();
